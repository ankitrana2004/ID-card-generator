import React, { useState } from 'react';
import Form from './components/Form';
import IDCard from './components/IDCard';
import './App.css';

const App = () => {
  const [formData, setFormData] = useState({
    name: '',
    college: '',
    course: '',
    photo: ''
  });

  const [preview, setPreview] = useState(false); // form ya preview toggle

  return (
    <div className="app">
      <h1>ID Card Generator</h1>

      {/* Conditional rendering */}
      {!preview ? (
        <Form
          formData={formData}
          setFormData={setFormData}
          setPreview={setPreview}
        />
      ) : (
        <IDCard
          formData={formData}
          goBack={() => setPreview(false)} // 👈 back button ke liye function
        />
      )}
    </div>
  );
};

export default App;

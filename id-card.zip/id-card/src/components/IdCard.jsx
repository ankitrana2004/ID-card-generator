import React, { useRef } from 'react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const IDCard = ({ formData, goBack }) => {
  const cardRef = useRef();

  const handleDownload = async () => {
    const canvas = await html2canvas(cardRef.current);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save('id_card.pdf');
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '20px', padding:'50px'}}>
      {/* 👇 ID Card Template */}
      <div
        ref={cardRef}
        style={{
          width: '300px',
          margin: '0 auto',
          padding: '20px',
          border: '2px solid #333',
          borderRadius: '10px',
          boxShadow: '0 0 10px rgba(0,0,0,0.2)',
          backgroundColor: 'white'
        }}
      >
          <h1 id='h1'><strong></strong> {formData.college}</h1>
        <img
          src={formData.photo}
          alt="User"
          style={{ width: '100px', height: '100px', borderRadius: '50%', objectFit: 'cover'}}
        />
        <h2>{formData.name}</h2>
        <p id='p'><strong>Course:</strong> {formData.course}</p>
      </div>

      {/* 👇 Buttons */}
      <div style={{ marginTop: '20px' }}>
        <button
          onClick={handleDownload}
          style={{
            padding: '10px 20px',
            marginRight: '10px',
            backgroundColor: '#28a745',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          📥 Download PDF
        </button>

        <button
          onClick={goBack}
          style={{
            padding: '10px 20px',
            backgroundColor: '#007bff',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          🔙 Edit Info
        </button>
      </div>
    </div>
  );
};

export default IDCard;
